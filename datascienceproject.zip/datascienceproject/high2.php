<?php
$op=$_POST['meal'];
if($op==1){

 header('location:hbreakfast.html');	
}
if($op==2){

 header('location:hlunch.html');	
}
if($op==3){

 header('location:hsnacks.html');	
}
if($op==4){

 header('location:hdinner.html');	
}
?>