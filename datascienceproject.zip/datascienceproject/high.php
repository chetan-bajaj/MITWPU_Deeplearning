<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://use.fontawesome.com/ab8426ec11.js"></script>
<style>
.customButton{
            /* background: linear-gradient(90deg, rgba(62,204,215,1) 0%, rgba(74,114,233,1) 36%, rgba(183,50,235,1) 100%); */
            background-color: blue;//#F1AEAE;
            color:#fff;
            text-transform: uppercase;
        }
h1{
	font-size:25px;
}

h2{
	font-size:25px;
}

h3{
	font-size:20px;
}
.i1{
  text-align:center;
    background-size:contain;
}

.c1{
 margin:4% 0 0 0;
 
}

.card-body{
  font-family: 'Montserrat',sans-serif;
  text-align: left;
}

.card-body h3{
  margin-bottom:0;
}

.card-body h6{

font-weight:bold;
margin-bottom: 0;
margin-top:7%;
}

.card-body p{
  font-size: 0.9rem;
  margin-bottom: 0.3rem;
}
.navbar{
	height : 40px;
}

</style>

  </head>
<body>
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<nav>
        <nav class="navbar navbar-expand-xs navbar-light bg-primary">
		
		   
            <div class="container-fluid ">
			
           
                <a class="navbar-brand" href="#">
				
                    <img src="dclogo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">Diabetic Compass</img>
                     
                </a>
				
                 </div>
                
				
                            
                       
                        

                    

               

                
				
				
            
        </nav>
    </nav>

    
<div class="container-fluid">
    
	<div class="row h-75 align-items-center justify-content-center text-center">
    <h1>Your sugar level is high!</h1>
	<img src="high.png" width="85" height="60"></img>
	<h2>The system predicts that you are suffering from diabetes.</h2>
	<form method="post" action="high2.php">
	<h3>The system has recommendations of food choices for high sugar level.</h3>
	<input type="radio" name="meal" value=1>
	<label for="option"><h3>Breakfast</h3></label><br>
	<input type="radio" name="meal" value=2>
	<label for="option"><h3>Lunch</h3></label><br>
	<input type="radio" name="meal" value=3>
	<label for="option"><h3>Snacks</h3></label><br>
	<input type="radio" name="meal" value=4>
	<label for="option"><h3>Dinner</h3></label><br>
	<div class="p-2 d-grid gap-1 bd-highlight text-center"> <button type="submit" class="btn customButton rounded-pill"><b>Submit</b></button></div>
	</form>
	
</div>

<a href="diabeticcompass.php"><img src="prevbutton.png"/></a>
</body>
</html>
