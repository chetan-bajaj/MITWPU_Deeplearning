
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <title>Document</title>
    <style>
        /* body{
            background-color:#e5e5e5;
            text-align: center;
        }
        form{
            background-color: #fff;
            width: 50%;
            height: 50vh;
            margin-top: 25vh;
            margin-left: 50vh;
            text-overflow: none;
            box-sizing: border-box;
            padding-top: 75px;
        }
        h1{
        } */
        .customButton{
            /* background: linear-gradient(90deg, rgba(62,204,215,1) 0%, rgba(74,114,233,1) 36%, rgba(183,50,235,1) 100%); */
            background-color: blue;//#F1AEAE;
            color:#fff;
            text-transform: uppercase;
        }
        .borderBottom{
      
            
        }
    </style>
</head>
<body class = "d-flex justify-content-center mt-5">
    <!-- <div>
        <form>
            <h1>Welcome</h1>
            <p>

                <input type = "email" >
            </p>
            <p>
                <input type = "password">

            </p>
            <p>
                <input type= "submit">

            </p>
        </form>
    </div> -->
    <!-- "d-inline-flex p-2 bd-highlight" -->
    <div class="card d-inline-flex  bd-highlight  p-2">
      
        <div class="card-body">
          
		  <h5 class="card-title text-center">Diabetic Compass</h5>
		  <img src="dclogo.png" width="300" height="150" align="center"></img>
          <p class="text-center">
          
        </p>
          <p class="card-text">
            <div class="d-flex flex-column bd-highlight mb-3">
                <form method="post" action="levellabelcheck.php">
                  
                

                <div class="p-2 bd-highlight">
                    <label class="form-label">Please enter your Sugar level in mmol/L :</label>
                       <input type="Number" class="form-control " name="sugarlevel" id="sl">
                </div>
                <div class="p-2 d-grid gap-1 bd-highlight text-center"> <button type="submit" class="btn customButton rounded-pill"><b>Submit</b></button></div>
            </form>  
            </div>

        
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>
</html>