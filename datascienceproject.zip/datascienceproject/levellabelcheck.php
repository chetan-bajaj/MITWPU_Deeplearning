<?php

$sl=$_POST['sugarlevel'];
if($sl>130)
{
 header('location:high.html');
}
else if($sl>=80 && $sl<=130)
{
 header('location:normal.html');
}
else if($sl>0 && $sl<130)
{
    header('location:low.html');
}
else
    header('location:error.html');
?>
	