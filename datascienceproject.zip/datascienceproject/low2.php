<?php
$op=$_POST['meal'];
if($op==1){

 header('location:lbreakfast.html');	
}
if($op==2){

 header('location:llunch.html');	
}
if($op==3){

 header('location:lsnacks.html');	
}
if($op==4){

 header('location:ldinner.html');	
}
?>